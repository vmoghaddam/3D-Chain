﻿'use strict';
app.factory('pageService', ['$http', '$q', 'ngAuthSettings', '$rootScope', function ($http, $q, ngAuthSettings, $rootScope) {



    var serviceFactory = {};
 

    return serviceFactory;

}]);