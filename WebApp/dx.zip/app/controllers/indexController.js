﻿'use strict';
app.controller('indexController', ['$scope', '$location',  function ($scope, $location ) {

    //$scope.logOut = function () {
    //    authService.logOut();
    //    $location.path('/home');
    //}

    //$scope.authentication = authService.authentication;

}]);